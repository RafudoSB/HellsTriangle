/*Rafael da Silva Barros, 27 anos
Formado em Sistema de Informação, Usp Leste
*/

package hellstriangle;
public class HellsTriangle {

    public static void main(String[] args) {
        //criei 4 arrays de um unico vetor para simbolizar as linhas do triângulo
        Integer topo[] = new Integer [1];
        Integer SegundaLinha[] = new Integer [2]; 
        Integer TerceiraLinha[] = new Integer [3];
        Integer QuartaLinha[] = new Integer [4];
        
        //define os valores que estarão nas linhas do triângulo
        topo[0] = 6;
        
        SegundaLinha[0] = 3;
        SegundaLinha[1] = 5;
        
        TerceiraLinha[0] = 9;
        TerceiraLinha[1] = 7;
        TerceiraLinha[2] = 1;     
        
        QuartaLinha[0] = 4;
        QuartaLinha[1] = 6; 
        QuartaLinha[2] = 8;
        QuartaLinha[3] = 4;
        
        //criei uma matriz para representar a estrutura do triangulo e suas linhas definidas acima
        Integer [][] triangulo = {topo,SegundaLinha,TerceiraLinha,QuartaLinha};
        
        MaximumTotalFromTopToBottom(triangulo);        
                
    }

    //método para calcular a soma maxima do topo à base 
    public static void MaximumTotalFromTopToBottom (Integer[][] triangulo){
            
        //variáveis que irãoa armazenar, respectivamente, a soma total dos valores, a soma máxima possível e os valores utilizado na soma máxima possível
        int soma = 0;
        int Max = 0;            
        int n1 = 0;
        int n2 = 0;
        int n3 = 0;
        int n4 = 0;
        
        //loop para navegar nos valores do triangulo e realizar os devidos calculos
        for(int i = 0; i < triangulo[0].length; i++){
            for(int j = 0; j <= i+1; j++){
                for(int w = j; w <= j+1; w++){
                    for(int t = w; t <= w+1; t++){
                        
                        soma = triangulo[0][i] + triangulo[1][j] + triangulo[2][w] + triangulo[3][t]; //calcula a maior soma a partir do topo
                        
                        if(soma > Max){
                            
                            Max = soma;    //armazena a maior soma
                            
                            //armazenam os valor que somados na soma
                            n1 = triangulo[0][i]; 
                            n2 = triangulo[1][j];
                            n3 = triangulo[2][w];
                            n4 = triangulo[3][t];
                            
                        }                        
                    }

                }                    
            }          
        }
        //mostra na tela o soma máxima possível
        System.out.print("Maximum Total From Top:" + " " + n1 + " " + "+" + n2 + " " + "+" + n3 + " " + "+" + n4 + " " + "+" + " " + "=" + " " + Max);
    }
}


    
       

